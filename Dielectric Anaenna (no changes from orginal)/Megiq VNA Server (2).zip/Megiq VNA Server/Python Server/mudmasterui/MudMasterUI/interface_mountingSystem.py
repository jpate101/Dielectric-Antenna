"""
*******************************************************************************
@file   interface_MountingSystem.py
@author Scott Thomason
@date   30 Sep 2021
@brief  Interface for the mounting system. This controls the actuator that 
        adjusts the height. It keeps track of the current system height and 
        adjusts it to ensure it is at the desired height.

REFERENCE:

*******************************************************************************
    Functions
*******************************************************************************

*******************************************************************************
"""

""" Imports 
*******************************************************************************
"""

import os
import requests
import time
import threading
import json
import serial
import serial.tools.list_ports

""" Defines
*******************************************************************************
"""
deviceDescriptions = ['Arduino']

""" Functions
*******************************************************************************
"""

def findSerialPorts():
    """ @brief  Finds all serial devices connected to the system and makes a list of 
                the ports.
        @param  None
        @retval List of serial ports

    """
    portList = []
    comports = list(serial.tools.list_ports.comports())
    for p in comports:
        if any(desc in p.description for desc in deviceDescriptions):
            print(p, '<description:>', p.description, '<manufacturer:>', p.manufacturer, '<product:>', p.product, '<description length:>', len(p.description))
            portList.append(p)

    return portList


""" Classes
*******************************************************************************
"""

class MountingSystem_Manager(object):
    def __init__(self, app=None):
        """ @brief  Initialisation function for the mounting system manager.
            @param  None
            @retval None - Initialisation function.

        """
        self._app = None
        self._serialPort = None
        self._status = -1 # 0 = good, 1 = bad, -1 = not connected
        self._calibrated = False
        self._currentHeight = None
        self._lastMessageTime = None
        self._config_commands = None
        self._current_actuator = 0

        self._heightRange = {'min': None, 'max': None}

        self._commandQueue = []

        self._managementThreadRun = False
        
        self._lock = threading.Lock() # lock used to protect data when it is being changed.
        # start the management thread
        
        if(app != None):
            self.init_app(app)
        

    def init_app(self, app):
        """ @brief  App initialiser used for application factory structure.
            @param  app - reference to the application
            @retval None

        """
        self._app = app
        self._config_commands = self._app.config['CONFIG_SYSTEM'].get('mountingSystemCommands', {})
        self._config_limits = self._app.config['CONFIG_SYSTEM'].get('mountingSystem', {'actuator_max': 130, 'actuator_min': 0})  # defaults to 130 if there is no config
        

        if(self._serialPort == None):
            self.openSerial()

    
    def start_manager_thread(self):
        """ @brief  Starts the fitting handler thread if the a reference to the application and database exist.
            @param  None
            @retval None

        """
        if(self._app != None):

            self._processThread = threading.Thread(target = self.deviceManagementThread)
            self._processThread.start()


    """ Serial Communications
    ***********************************************************************
    """
    def openSerial(self):
        """ @brief  Attempts to find and open the serial port.
            @param  None
            @retval None

        """
        try:
            if(self._serialPort == None):
                availablePorts = findSerialPorts()
                if(len(availablePorts) >= 1):
                    # found the arduino
                    print('Found Arduino')
                    print(availablePorts)
                    self._serialPort = serial.Serial(port = availablePorts[0].device, 
                                                    baudrate = 9600, 
                                                    timeout = 1.0, 
                                                    bytesize = serial.EIGHTBITS)

                    self._serialNo = availablePorts[0].serial_number

                    print('Serial No.:', self._serialNo)
                    print('connected')
                    self._status = 0

        except Exception as e:
            print('Communication Error: permission. {}'.format(e))
            self._status = -1


    def sendReceive(self, command):
        """ 
            @brief  Sends the provided command to the device and listens for a reply.
            @param  command - string of commands to be processed by the Arduino.
            @retval None

        """
        if not command.endswith('\n\r'):
            command = command + '\n\r'

        try:
            if(self._serialPort == None):
                self.openSerial()

            if(self._serialPort != None):

                self._serialPort.write(command.encode())

                time.sleep(0.5)
                reply = self._serialPort.read(self._serialPort.inWaiting()).decode("utf-8")

                return reply

        except Exception as e:
            print('Communication Error: permission. {}'.format(e))
            self._status = 1
            self._serialPort.close()
            self._serialPort = None  # reset to None to show that it isn't present
            self._status = -1

        return ''


    def sendOnly(self, command):
        """ 
            @brief  Sends the provided command to the device.
            @param  command - string of commands to be processed by the Arduino.
            @retval None

        """
        if not command.endswith('\n\r'):
            command = command + '\n\r'

        try:
            if(self._serialPort == None):
                self.openSerial()

            if(self._serialPort != None):
                self._serialPort.write(command.encode())

                time.sleep(0.5)

        except Exception as e:
            print('Communication Error: permission. {}'.format(e))
            self._status = 1
            self._serialPort.close()
            self._serialPort = None  # reset to None to show that it isn't present
            self._status = -1



    """ General Control Functions
    ***********************************************************************
    """

    def set_height(self, height):
        """ @brief  Sets the height of the mounting system.
            @param  height - desired height of the antenna
            @retval None

        """
        # check that there is a height range set
        if(self._heightRange['min'] is not None and self._heightRange['max'] is not None):
            # if it is less than the minimum, fix it to the minimum
            if(height < self._heightRange['min']):
                height = self._heightRange['min']

            # if it is greater than the maximum, fix it to the maximum
            if(height > self._heightRange['max']):
                height = self._heightRange['max']

            # now send the new height to the controller
            commandString = '{},{:3d}'.format(self._config_commands['height']['set'], height)

            self.sendOnly(commandString)

        # get the current height back from the mounting system
        commandString = '{}'.format(self._config_commands['height']['get'])

        msg_height = self.sendReceive(commandString)

        # try to return the height as a float, else, return None
        try:
            return(float(msg_height))

        except Exception as e:
            print(e)
            print(msg_height)
            return(None)


    def set_actuator(self, position, testing=False):
        """ @brief  Sets the height of the mounting system.
            @param  position - extension length of the actuator
            @retval self._actuator_position_target

        """
        # check that there is a height range set
        if('actuator_min' in self._config_limits and 'actuator_max' in self._config_limits):
            # if it is less than the minimum, fix it to the minimum
            if(position < self._config_limits['actuator_min']):
                position = self._config_limits['actuator_min']

            # if it is greater than the maximum, fix it to the maximum
            if(position > self._config_limits['actuator_max']):
                position = self._config_limits['actuator_max']

            # now send the new height to the controller - if not in testing mode
            if not testing:
                print('setting actuator to {}'.format(position))
                commandString = '{},{:3d}'.format(self._config_commands['actuator']['set'], position)

                self.sendOnly(commandString)

            self._current_actuator = position

        return self._current_actuator


    def move_actuator(self, distance, testing=False):
        """ @brief  Moves the actuator by the specified distance.
            @param  distance - distance to move the actuator
            @retval self._actuator_position_target

        """
        new_position = self._current_actuator + distance
        # check that there is a height range set
        if('actuator_min' in self._config_limits and 'actuator_max' in self._config_limits):

            
            # if it is less than the minimum, fix it to the minimum
            if(new_position < self._config_limits['actuator_min']):
                new_position = self._config_limits['actuator_min']

            # if it is greater than the maximum, fix it to the maximum
            if(new_position > self._config_limits['actuator_max']):
                new_position = self._config_limits['actuator_max']

            # now send the new height to the controller - if not in testing mode
            if not testing:
                commandString = '{},{:3d}'.format(self._config_commands['actuator']['set'], new_position)

                self.sendOnly(commandString)

            self._current_actuator = new_position

        return self._current_actuator


    def run_calibration(self):
        """ @brief  Instructs the mounting system controller to calibrate 
                    the height.
                    The calibration involves retracting the actuator to 
                    find the maximum height, then extending it until it 
                    reaches the lowest height.
            @param  None
            @retval None

        """
        # send the calibration request to the controller.
        commandString = '{}'.format(self._config_commands['mode']['set'], self._config_commands['mode']['modes']['cal'])

        msg_height = self.sendReceive(commandString)
        # after completing, it will send back the height range
        min = 250
        max = 500



        return {'min': min, 'max': max}


    """ General Query Functions
    ***********************************************************************
    """

    def get_height(self):
        """ @brief  Gets the current height of the mounting system.
            @param  None
            @retval Current height

        """
        return self._currentHeight


    def get_actuator_target(self):
        """ @brief  Gets the current actuator target.
            @param  None
            @retval Current height

        """
        return self._current_actuator


    def get_actuator_position(self):
        """ @brief  Gets the current actuator position.
            @param  None
            @retval Current actuator position

        """
        commandString = '{}'.format(self._config_commands['actuator']['get'])

        msg = self.sendReceive(commandString)
        try:
            return float(msg.split(',')[0])

        except Exception as e:
            print(e)
            print(msg)
            return None


    def get_status(self):
        """ @brief  Gets the current status of the mounting system.
            @param  None
            @retval Current status

        """
        return self._status
    


    """ Module Thread - Not used
    ***********************************************************************
    """

    def deviceManagementThread(self):
        """ @brief  This thread runs the mounting system. It will send 
                    commands to set the height of the module and receive any 
                    data that has been sent back. 
            @param  None
            @retval None

        """
        # initial setup

        print('mounting system control thread start')
        print(self._serialPort)

        # while loop
        while(self._managementThreadRun):

            # now check if there is any messages from the mounting system
            if(self._serialPort == None):
                self.openSerial()

            if(self._serialPort != None):
                # use try to catch any disconnects on the mounting system
                try:
                    receivedData = self._serialPort.readline().decode()
                    self._status = 0

                except Exception as e:
                    print('Communication Error: permission. {}'.format(e))
                    self._status = 1
                    self._serialPort.close()
                    self._serialPort = None  # reset to None to show that it isn't present
                    receivedData = ''  # make it a list of no data


                
                if(len(receivedData) > 0):
                    self._lastMessageTime = time.monotonic()

                    # split the data at the commas to process
                    splitData = receivedData.split(',')

                    if(splitData[0] == 'h'):
                        # current height
                        self._currentHeight = float(splitData[1])

                    
            time.sleep(0.1)