Tool Files:

* Delete MiqVNA Typelibs.reg
	Delete register entries for the MiQVNA typelib, in case of version confusion during development.

* MiQVNA.IDL
	Formal MiQVNA typelib interface description.